package mec.gov.py.gestionestudiantesuniversitarios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionEstudiantesUniversitariosApplicationTests {

	@Test
	void contextLoads() {
	}

}
